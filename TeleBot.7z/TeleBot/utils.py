import requests
import json
from config import keys, TOKEN


class ConvExp(Exception):
    pass


class CryptoConv:
    @staticmethod
    def convert(quote: str, base: str, amount: str):

        if quote == base:
            raise ConvExp('Сравниваемые валюты должны быть разными')

        quote_ticker, base_ticker = keys[quote], keys[base]

        if quote == base:
            raise ConvExp('Невозможно перевести одинаковые валюты {base}')

        try:
            quote_ticker = keys[quote]
        except KeyError:
            raise ConvExp('Не удалось обработать валюты {quote}')

        try:
            base_ticker = keys[base]
        except KeyError:
            raise ConvExp('Не удалось обработать валюты {base}')

        try:
            amount = float(amount)

        except ValueError:
            raise ConvExp('Не удалось обрабоать количество {amount}')

        r = requests.get(f'https://api.exchangeratesapi.io/latest?base={quote_ticker}&symbols={base_ticker}')
        total_base = json.loads(r.content)["rates"][keys[base]] * amount
        total_base = float('{:.2f}'.format(total_base))
        return total_base
