TOKEN = '1688669915:AAFNMlkOxBIYaJQYZQh8aergyRWSBRYzY5Q'

keys = {
    'Евро': 'EUR',
    'Доллар': 'USD',
    'Рубль': 'RUB'
}